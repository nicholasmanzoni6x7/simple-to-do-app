import React, {useState} from 'react';
import Tasks from './components/Tasks.jsx'
import TaskAdder from './components/TaskAdder.jsx'
import './App.css';

function App() {
  
  const [tasks, setTasks] = useState([{
        content: "Start a cult", finshed: false},
        {content: "Awaken old gods", finished: false},
        {content: "Buy cheese", finished: false}
      ]
    );
  return (
    <div className="App">
      <TaskAdder tasks={tasks} setTasks={setTasks} />
      <Tasks tasks={tasks} setTasks={setTasks}/>
    </div>
  );
}

export default App;
